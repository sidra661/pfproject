#include "filehandler.h"

vector<Row> readTXT(const string& filename) {
    vector<Row> data;
    ifstream file(filename);
    if (!file.is_open()) {
        return data;
    }

    string line;
    getline(file, line); // skip header row

    while (getline(file, line)) {
        Row row;
        string field = "";
        bool inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line[i];
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                row.fields.push_back(field);
                field = "";
            } else {
                field += c;
            }
        }
        row.fields.push_back(field); // last field
        data.push_back(row);
    }
    file.close();
    return data;
}

void writeTXT(const string& filename, const vector<Row>& data) {
    ofstream file(filename);

    // Write header based on filename
    if (filename == "students.txt") {
        file << "roll,name,dept,cgpa,status" << endl;
    } else if (filename == "courses.txt") {
        file << "code,title,credits,seats,prereq" << endl;
    } else if (filename == "enrollments.txt") {
        file << "roll,course_code,semester,status" << endl;
    } else if (filename == "attendance_log.txt") {
        file << "roll,course_code,date,status" << endl;
    } else if (filename == "fees.txt") {
        file << "roll,semester,amount_due,amount_paid,due_date,paid_date" << endl;
    } else if (filename == "grades.txt") {
        file << "roll,course_code,semester,quiz_avg,asgn_avg,mid,final,total,grade" << endl;
    }

    for (int i = 0; i < data.size(); i++) {
        for (int j = 0; j < data[i].fields.size(); j++) {
            if (j > 0) file << ",";
            // Wrap in quotes if contains comma
            bool hasComma = false;
            for (int k = 0; k < data[i].fields[j].length(); k++) {
                if (data[i].fields[j][k] == ',') {
                    hasComma = true;
                    break;
                }
            }
            if (hasComma) {
                file << '"' << data[i].fields[j] << '"';
            } else {
                file << data[i].fields[j];
            }
        }
        file << endl;
    }
    file.close();
}

void appendTXT(const string& filename, const Row& row) {
    ofstream file(filename, ios::app);
    for (int i = 0; i < row.fields.size(); i++) {
        if (i > 0) file << ",";
        bool hasComma = false;
        for (int j = 0; j < row.fields[i].length(); j++) {
            if (row.fields[i][j] == ',') {
                hasComma = true;
                break;
            }
        }
        if (hasComma) {
            file << '"' << row.fields[i] << '"';
        } else {
            file << row.fields[i];
        }
    }
    file << endl;
    file.close();
}

vector<string> findRow(const string& filename, int colIndex, const string& value) {
    vector<Row> data = readTXT(filename);
    for (int i = 0; i < data.size(); i++) {
        if (data[i].fields[colIndex] == value) {
            return data[i].fields;
        }
    }
    return vector<string>(); // empty if not found
}

bool rowExists(const string& filename, int colIndex, const string& value) {
    return findRow(filename, colIndex, value).size() > 0;
}
