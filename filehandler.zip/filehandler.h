#ifndef FILEHANDLER_H
#define FILEHANDLER_H

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;

struct Row {
    vector<string> fields;
};

vector<Row> readTXT(const string& filename);
void writeTXT(const string& filename, const vector<Row>& data);
void appendTXT(const string& filename, const Row& row);
vector<string> findRow(const string& filename, int colIndex, const string& value);
bool rowExists(const string& filename, int colIndex, const string& value);

#endif
