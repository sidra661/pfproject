#include "student_ops.h"

bool validateRollFormat(const string& roll) {
    // Format: BSAI-YY-XXX (10 characters total)
    if (roll.length() != 10) return false;
    if (roll.substr(0, 5) != "BSAI-") return false;
    if (roll[5] < '0' || roll[5] > '9') return false;
    if (roll[6] < '0' || roll[6] > '9') return false;
    if (roll[7] != '-') return false;
    if (roll[8] < '0' || roll[8] > '9') return false;
    if (roll[9] < '0' || roll[9] > '9') return false;
    return true;
}

bool validateName(const string& name) {
    for (int i = 0; i < name.length(); i++) {
        if (name[i] >= '0' && name[i] <= '9') return false;
    }
    return true;
}

void addStudent(const string& roll, const string& name, const string& dept, float cgpa) {
    if (!validateRollFormat(roll)) {
        cout << "Invalid roll format! Use BSAI-YY-XXX" << endl;
        return;
    }
    if (rowExists("students.txt", 0, roll)) {
        cout << "Student already exists!" << endl;
        return;
    }
    if (!validateName(name)) {
        cout << "Name cannot contain digits!" << endl;
        return;
    }
    if (cgpa < 0.0 || cgpa > 4.0) {
        cout << "CGPA must be between 0.0 and 4.0!" << endl;
        return;
    }

    Row row;
    row.fields.push_back(roll);
    row.fields.push_back(name);
    row.fields.push_back(dept);

    // Format CGPA to 2 decimal places manually
    string cgpaStr = to_string(cgpa);
    int dotPos = -1;
    for (int i = 0; i < cgpaStr.length(); i++) {
        if (cgpaStr[i] == '.') {
            dotPos = i;
            break;
        }
    }
    if (dotPos != -1 && dotPos + 2 < cgpaStr.length()) {
        cgpaStr = cgpaStr.substr(0, dotPos + 3);
    }
    row.fields.push_back(cgpaStr);
    row.fields.push_back("active");
    appendTXT("students.txt", row);
    cout << "Student added successfully!" << endl;
}

vector<string> searchByRoll(const string& roll) {
    return findRow("students.txt", 0, roll);
}

vector<vector<string>> searchByName(const string& nameSubstring) {
    vector<Row> all = readTXT("students.txt");
    vector<vector<string>> matches;
    for (int i = 0; i < all.size(); i++) {
        string name = all[i].fields[1];
        if (name.find(nameSubstring) != string::npos) {
            matches.push_back(all[i].fields);
        }
    }
    return matches;
}

void updateStudent(const string& roll, int fieldIndex, const string& newValue) {
    vector<Row> data = readTXT("students.txt");
    bool found = false;
    for (int i = 0; i < data.size(); i++) {
        if (data[i].fields[0] == roll) {
            data[i].fields[fieldIndex] = newValue;
            found = true;
            break;
        }
    }
    if (found) {
        writeTXT("students.txt", data);
        cout << "Updated successfully!" << endl;
    } else {
        cout << "Student not found!" << endl;
    }
}

void softDelete(const string& roll) {
    updateStudent(roll, 4, "inactive");
}

// Selection sort for active students by roll number
vector<vector<string>> listActiveStudents() {
    vector<Row> all = readTXT("students.txt");
    vector<Row> active;

    // Filter active students
    for (int i = 0; i < all.size(); i++) {
        if (all[i].fields[4] == "active") {
            active.push_back(all[i]);
        }
    }

    // Selection sort by roll number (ascending)
    for (int i = 0; i < active.size() - 1; i++) {
        int minIdx = i;
        for (int j = i + 1; j < active.size(); j++) {
            if (active[j].fields[0] < active[minIdx].fields[0]) {
                minIdx = j;
            }
        }
        if (minIdx != i) {
            Row temp = active[i];
            active[i] = active[minIdx];
            active[minIdx] = temp;
        }
    }

    vector<vector<string>> result;
    for (int i = 0; i < active.size(); i++) {
        result.push_back(active[i].fields);
    }
    return result;
}
