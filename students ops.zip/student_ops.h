#ifndef STUDENT_OPS_H
#define STUDENT_OPS_H

#include "filehandler.h"

bool validateRollFormat(const string& roll);
bool validateName(const string& name);
void addStudent(const string& roll, const string& name, const string& dept, float cgpa);
vector<string> searchByRoll(const string& roll);
vector<vector<string>> searchByName(const string& nameSubstring);
void updateStudent(const string& roll, int fieldIndex, const string& newValue);
void softDelete(const string& roll);
vector<vector<string>> listActiveStudents();

#endif
